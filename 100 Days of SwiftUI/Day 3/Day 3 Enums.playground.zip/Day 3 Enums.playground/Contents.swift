import Cocoa

//A enum is short for enumeration
// It's a set of named values that we can use in our code

//They don’t have any special meaning to Swift, but they are more efficient and safer, so you’ll use them a lot in your code.

//Let's look at a problem enums solve
//Let's say a user needs to select a day

var selectedDay = "Monday"
selectedDay = "Tuesday"
selectedDay = "Fri"
selectedDay = "April"
selectedDay = "Sunday "

// Now as you can see, although we can get a day from the user, there exists a chance for input errors
// To solve this we can create an enum that contains a list of values that are only possible. Similar to how Booleans can only have true or false,our Days can only have days

enum days{
    case Monday
    case Tuesday
    case Wednesday
    case Thursday
    case Friday
    case Saturday
    case Sunday
}

// this is a real pain to type so this is easier

enum weekend{
    case Saturday, Sunday
}

// Now we can use enums like so

var fixedSelectedDay = days.Monday
fixedSelectedDay = .Friday

print(fixedSelectedDay)
//WOW!!! AMAZING!!! RAD!!!
