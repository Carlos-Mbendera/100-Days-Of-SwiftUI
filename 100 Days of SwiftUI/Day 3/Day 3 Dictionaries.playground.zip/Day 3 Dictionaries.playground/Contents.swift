import Cocoa

//dictionaries are basically arrays with custom indexes
// This is useful for more complex groups of data. For example, the details of an employee

var employeeZERO = ["name": "Big Boss", "Skills":"S++ Class", "Location":"Outer Heaven"]

//Now we can also create dictionaries in a more explict manner other than using this format

var idols = [String : String]()
//Now if we want to add the idols dictionary. We can easily do so by following the above method of
// Index : Value , Index : Value, ...

idols["Best"] =  "Me"
idols["Worst"] = "No One"

//now just like arrays all the other functions like .count work fine
//Also we can overwrite values by refrenceing the index just like an array

print(idols["Best"])
idols["Best"] = "You"
print(idols["Best"])

// NOTICE when we print either, it's an optional, this means there is a chance it can be empty. Which isn't ideal, so we can assign a default value for the evennt that it is empty

print(idols["Best", default: "Mates"])

// Lastly, not all dictionaries have to be only Strings, we can mix and match
var hasStudentGraduated = [String : Bool]()
hasStudentGraduated["Mike"] = false
hasStudentGraduated["Andrew"] = true

var heights = ["Carl" : 156, "Cherry": 159]


