import Cocoa

//Sets are very similar to arrays except for important things. They don't remember the order they're in and they don't allow duplicates
 var mainProts = Set(["Jin", "Mugen", "Fu"])

//Notice that we're basically creating an Array inside the parenthesis of Set()
print(mainProts)
//WHen we print this, we will see the order is different from the order we inputed it

//Since there is no order we can not append a set. We can INSERT. For example

var countries = Set<String>()
countries.insert("Malawi")
countries.insert("USA")
countries.insert("Finland")

//The main benefits of Sets are the differences between them and array. No duplicates.
// Moreover, by losing the order, it's very fast to access data in Sets. Not a small improvement, but a very fast huge leap.

//You can also sort and count a set. However, when you sort them, you're not getting a new set, just a normal array that's sorted is returend




