import Cocoa

// There may be times when we want to return multiple values from a function. Arrays and Dictionaries may seem like a good way but look at these

func getUsersArray() -> [String]{
    ["Taylor", "Swift"]
}

let user = getUsersArray()
print("Name: \(user[0]) \(user[1])")

func getUsersDict() -> [String : String]{
    [
            "firstName": "Taylor",
            "lastName": "Swift"
        ]
}

let userDic = getUsersDict()
print("Name: \(userDic["firstName", default: "Anonymous"]) \(userDic["lastName", default: "Anonymous"])")

//With both examples, the code is messy and also not ideal. Any changes to the array could easily change the functionality. We also can't tell ahead of time if the values are there.

//The best way to deal with this is with TUPLES
//Like Arrays and Dict. They let us have multiple values in single const or var
//But they have a fixed size and can have a variety of data types

func getUserTuple() -> (firstName: String, lastName: String){
    (firstName: "Taylor", lastName : "Swift")
}

let userTup = getUserTuple()
print("Name: \(userTup.firstName) \(userTup.lastName)")

/*
 I know tuples seem awfully similar to dictionaries, but they are different:

 When you access values in a dictionary, Swift can’t know ahead of time whether they are present or not. Yes, we knew that user["firstName"] was going to be there, but Swift can’t be sure and so we need to provide a default value.
 When you access values in a tuple, Swift does know ahead of time that it is available because the tuple says it will be available.
 We access values using user.firstName: it’s not a string, so there’s also no chance of typos.
 Our dictionary might contain hundreds of other values alongside "firstName", but our tuple can’t – we must list all the values it will contain, and as a result it’s guaranteed to contain them all and nothing else.
 */

//Also since Swift knows what the Tuples Names are supposed to be. We can write code like this:
func ShortergetUserTuple() -> (firstName: String, lastName: String){
    ("Taylor", "Swift")
}

//If you don't get your Tuples Names, you can read them use indices
func getUserTupleShort() -> (String, String){
    ("Taylor", "Swift")
}

let userTupShort = getUserTupleShort()
print("Name: \(userTupShort.0) \(userTupShort.1)")
//Don't worry about there being no value at the index. Cause Swift knows exactly how many values are supposessed to be present

//There is a way of us getting the Tuple values directly and assign them to a variable. This is called De Structuring

let (firstName, lastName) = getUserTuple()
print("De Structured \(firstName) and \(lastName)")

//You can even omit some values, if you don't need them

let(name,_) = getUserTuple()
print("Hello \(name)")
