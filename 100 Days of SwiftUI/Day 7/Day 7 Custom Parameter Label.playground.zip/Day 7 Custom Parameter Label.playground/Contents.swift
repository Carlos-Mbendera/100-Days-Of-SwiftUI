import Cocoa

//The parameter labels of functions in Swift are very important as they let the language know which function we want to call
//For example, we can have the multiple functions with the same name. As long as their parameter is different then they won't be an issue

func hireEmployee(name: String) { }
func hireEmployee(title: String) { }
func hireEmployee(location: String) { }

//However, in some cases, we don't really need a label cause the use case is rather specifc. For example,

func isUppercase(string: String) -> Bool {
    string == string.uppercased()
}

let string = "HELLO, WORLD"
let result = isUppercase(string: string)

//Here in isUppercase, we have a label but do we really need a label? If we don't want our Function to need a parameter label, we add _

func NoLabelisUppercase(_ string: String) -> Bool {
    string == string.uppercased()
}

let noLabelString = "HELLO, WORLD"
let noLabelresult = NoLabelisUppercase(noLabelString)

//Other examples are .append, .count, .insert

// We can also set two parameter names. One for calling the function and one for use inside it. Instead of an underscore, we just put a external name then internal name

func printTimesTables(for number: Int) {
    for i in 1...12 {
        print("\(i) x \(number) is \(i * number)")
    }
}

printTimesTables(for: 5)
